import QtQuick 2.15

// 动作按钮（对齐 island.cpp 607-626 的 actions 按钮）
//
// 被控端岛的动作来自 showWithActions(title, desc, icon, form, actions, onAction, ms)
// 典型：["确认"] + 若干回复短语。QML 里 role 分主次：
//   primary   = 实心（如「确认」）
//   secondary = 描边（如回复短语）
Item {
    id: btn

    property var theme
    property string label: ""
    property string role: "secondary"     // primary | secondary
    property bool light: theme ? theme.light : false
    // ⚠️ enabled 用 Item 内置属性（不另声明）：父层 enabled=false 会经
    //    QQuickItem 的 enabled 传导链把子 MouseArea 一并禁用 —— 2026-10-15
    //    组件2「超额禁用」置灰点歌按钮即靠这条传导，无需自造禁用逻辑。

    signal clicked()

    implicitWidth: txt.implicitWidth + 22
    implicitHeight: 28

    Rectangle {
        anchors.fill: parent
        radius: height / 2
        opacity: btn.enabled ? 1.0 : 0.4
        color: {
            if (btn.role === "primary")
                return btn.light ? "#161616" : "#FAFAFA"
            return btn.light ? Qt.rgba(0, 0, 0, 0.06) : Qt.rgba(1, 1, 1, 0.10)
        }
        border.width: btn.role === "primary" ? 0 : 1
        border.color: btn.light ? "#D0D0D0" : "#3C3C3C"

        // 2026-10-18：时长改用主题令牌（原硬编码 120）
        Behavior on color { ColorAnimation { duration: btn.theme ? btn.theme.durXShort : 120 } }

        Text {
            id: txt
            anchors.centerIn: parent
            text: btn.label
            font.pixelSize: 13
            font.weight: Font.Medium
            color: {
                if (btn.role === "primary")
                    return btn.light ? "#FAFAFA" : "#161616"
                return btn.light ? "#161616" : "#FAFAFA"
            }
        }
    }

    // ⚠️ 只有一个 MouseArea：既处理点击又提供 pressed 状态给 scale。
    //    之前有两个 MouseArea，第二个 visible:false 收不到事件，pressed 恒 false。
    MouseArea {
        id: btnMa
        anchors.fill: parent
        enabled: btn.enabled
        cursorShape: btn.enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
        hoverEnabled: true
        onClicked: btn.clicked()
    }

    scale: btnMa.pressed ? 0.96 : 1.0
    // 按下回弹：用 durInstant（原硬编码 90）——要"跟上手"，不能慢
    Behavior on scale { NumberAnimation { duration: btn.theme ? btn.theme.durInstant : 90 } }
}
