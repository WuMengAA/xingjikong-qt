// 班级导航（ClassNav）· 骨架左栏 · #473 点单①「左班级导航 + 右班级工作台」
//
// 与 Sidebar 的区别：Sidebar 是"功能菜单"（仪表盘/班级看板/监控/设置），
// 本件是"以班为单位"的导航——上面是可变的班级列表（backend.classes），
// 下面是固定的系统组。老师的日常入口是班级，不是功能名。
//
// 三处设计要求：
//   ① 班级项带人数（在线/总数）：一眼看出哪个班在跑，不用点进去。
//      计数从 backend.devices 按 classCode 现算，不另建一份缓存。
//   ② 选中态 = 工业青左规 + secondaryContainer 底（沿用 Sidebar 语言，不另造）。
//   ③ 空态说人话：没有班级时提示"名单由云端下发"，而不是摆一个空列表。
//
// 竖屏不走本件（底栏放不下可变数量的班级）——竖屏用 BottomNav 的系统组，
// 班级切换走 TopBar 的「全部班级」下拉。
import QtQuick
import QtQuick.Layouts
import "../components/md3"
import "../island"          // SvgIcon

Item {
    id: nav

    property var md3: ({})
    property var ctx: null
    property var classes: []          // backend.classes [{code,name}]
    property var devices: []          // backend.devices（算每班在线数）
    property string currentClass: ""  // backend.currentClass
    property string section: ""       // 系统组选中：dash / classes / settings

    signal classPicked(string code)
    signal systemActivated(string key)
    signal classicRequested()

    readonly property int navWidth: 240
    readonly property int itemH: 56        // 系统项（MD3 navigation drawer 口径）
    readonly property int classH: 44       // 班级项（密度更高，班级可能很多）
    readonly property int iconPx: 20

    implicitWidth: navWidth
    Layout.fillHeight: true
    Layout.preferredWidth: navWidth

    /** 系统组（固定 4 项；监控是跳整页，仍走 navActivated 的统一分支）。 */
    readonly property var sysItems: [
        { key: "dash",     icon: "monitor",  label: "仪表盘" },
        { key: "monitor",  icon: "eye",      label: "运行监控" },
        { key: "settings", icon: "settings", label: "系统设置" }
    ]

    /** 某个班的在线/总数（现算，云端 devices 为唯一名单口径）。 */
    function countOf(code) {
        const ds = nav.devices
        var on = 0, all = 0
        for (var i = 0; i < ds.length; ++i) {
            const d = ds[i]
            if (!d) continue
            if ((d.classCode || "") !== code) continue
            all++
            if (d.online !== false) on++
        }
        return { on: on, all: all }
    }

    Rectangle { anchors.fill: parent; color: nav.md3 ? nav.md3.cSurfaceVar : "#E7E0EC" }

    // 右缘发丝线（与主内容区分界）
    Rectangle {
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.bottom: parent.bottom
        width: 1
        color: nav.md3 ? nav.md3.cOutlineVar : "#CAC4D0"
        opacity: 0.5
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 12
        spacing: 4

        // ── 品牌行 ──
        Item {
            Layout.fillWidth: true
            Layout.preferredHeight: 48
            Text {
                anchors.left: parent.left
                anchors.leftMargin: nav.md3 ? nav.md3.spM : 16
                anchors.verticalCenter: parent.verticalCenter
                text: "星集控"
                font.pixelSize: nav.md3 ? nav.md3.titleM : 16
                font.weight: Font.Medium
                color: nav.md3 ? nav.md3.cOnSurfaceVar : "#49454F"
            }
        }

        // ── 班级分组 ──
        Text {
            Layout.leftMargin: nav.md3 ? nav.md3.spM : 16
            Layout.topMargin: 8
            text: "班级"
            font.pixelSize: nav.md3 ? nav.md3.labelS : 11
            color: nav.md3 ? nav.md3.cOutline : "#79747E"
        }

        ListView {
            id: classList
            Layout.fillWidth: true
            Layout.fillHeight: true
            clip: true
            spacing: 2
            model: nav.classes
            boundsBehavior: Flickable.StopAtBounds

            delegate: Rectangle {
                id: clsRow
                required property var modelData
                readonly property bool active: nav.section === "classes"
                                                && nav.currentClass === (clsRow.modelData.code || "")
                readonly property var cnt: nav.countOf(clsRow.modelData.code || "")

                width: classList.width
                height: nav.classH
                radius: nav.md3 ? nav.md3.rM : 12
                color: clsRow.active
                       ? (nav.md3 ? nav.md3.cSecondaryCont : "#E8DEF8")
                       : (clsMa.containsMouse ? (nav.md3 ? nav.md3.cContHigh : "#ECE6F0") : "transparent")
                Behavior on color { ColorAnimation { duration: nav.md3 ? nav.md3.durShort : 200 } }

                Rectangle {
                    visible: clsRow.active
                    width: 3
                    radius: 1.5
                    anchors.left: parent.left
                    anchors.leftMargin: 4
                    anchors.top: parent.top
                    anchors.bottom: parent.bottom
                    anchors.topMargin: 12
                    anchors.bottomMargin: 12
                    color: nav.md3 ? nav.md3.cAccent : "#2FB8C6"
                }

                Text {
                    anchors.left: parent.left
                    anchors.leftMargin: nav.md3 ? nav.md3.spM : 16
                    anchors.right: cntTx.left
                    anchors.rightMargin: 8
                    anchors.verticalCenter: parent.verticalCenter
                    text: clsRow.modelData.name || clsRow.modelData.code || ""
                    elide: Text.ElideRight
                    font.pixelSize: nav.md3 ? nav.md3.body13 : 13
                    font.weight: clsRow.active ? Font.Medium : Font.Normal
                    color: clsRow.active
                           ? (nav.md3 ? nav.md3.cOnSecondaryCont : "#1D192B")
                           : (nav.md3 ? nav.md3.cOnSurface : "#1C1B1F")
                }

                Text {
                    id: cntTx
                    anchors.right: parent.right
                    anchors.rightMargin: nav.md3 ? nav.md3.spM : 16
                    anchors.verticalCenter: parent.verticalCenter
                    text: clsRow.cnt.on + "/" + clsRow.cnt.all
                    font.pixelSize: nav.md3 ? nav.md3.labelS : 11
                    font.family: "monospace"
                    color: clsRow.cnt.on > 0
                           ? (nav.md3 ? nav.md3.cOk : "#1B7A43")
                           : (nav.md3 ? nav.md3.cOutline : "#79747E")
                }

                MouseArea {
                    id: clsMa
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: nav.classPicked(clsRow.modelData.code || "")
                }
            }
        }

        // 班级空态（名单由云端下发，不是本地能造的）
        Text {
            Layout.fillWidth: true
            Layout.leftMargin: nav.md3 ? nav.md3.spM : 16
            visible: classList.count === 0
            text: "还没有班级名单\n登录后由云端下发"
            font.pixelSize: nav.md3 ? nav.md3.bodyS : 12
            wrapMode: Text.WordWrap
            color: nav.md3 ? nav.md3.cOutline : "#79747E"
        }

        // ── 系统组 ──
        Rectangle {
            Layout.fillWidth: true
            Layout.topMargin: 8
            Layout.bottomMargin: 4
            height: 1
            color: nav.md3 ? nav.md3.cOutlineVar : "#CAC4D0"
            opacity: 0.6
        }

        Repeater {
            model: nav.sysItems
            delegate: Rectangle {
                id: sysRow
                required property var modelData
                Layout.fillWidth: true
                Layout.preferredHeight: nav.itemH
                radius: nav.md3 ? nav.md3.rFull : 999
                color: (nav.section === modelData.key)
                       ? (nav.md3 ? nav.md3.cSecondaryCont : "#E8DEF8")
                       : (sysMa.containsMouse ? (nav.md3 ? nav.md3.cContHigh : "#ECE6F0") : "transparent")
                Behavior on color { ColorAnimation { duration: nav.md3 ? nav.md3.durShort : 200 } }

                Row {
                    anchors.left: parent.left
                    anchors.leftMargin: nav.md3 ? nav.md3.spM : 16
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 12

                    SvgIcon {
                        name: sysRow.modelData.icon
                        px: nav.iconPx
                        tint: (nav.section === sysRow.modelData.key)
                              ? (nav.md3 ? nav.md3.cOnSecondaryCont : "#1D192B")
                              : (nav.md3 ? nav.md3.cOnSurfaceVar : "#49454F")
                        anchors.verticalCenter: parent.verticalCenter
                    }
                    Text {
                        text: sysRow.modelData.label
                        font.pixelSize: nav.md3 ? nav.md3.bodyM : 14
                        font.weight: (nav.section === sysRow.modelData.key) ? Font.Medium : Font.Normal
                        color: (nav.section === sysRow.modelData.key)
                               ? (nav.md3 ? nav.md3.cOnSecondaryCont : "#1D192B")
                               : (nav.md3 ? nav.md3.cOnSurfaceVar : "#49454F")
                        anchors.verticalCenter: parent.verticalCenter
                    }
                }

                MouseArea {
                    id: sysMa
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: nav.systemActivated(sysRow.modelData.key)
                }
            }
        }

        // ── 返回经典界面（骨架与旧壳并存期必须有退路）──
        Item {
            Layout.fillWidth: true
            Layout.preferredHeight: 44
            Row {
                anchors.left: parent.left
                anchors.leftMargin: nav.md3 ? nav.md3.spM : 16
                anchors.verticalCenter: parent.verticalCenter
                spacing: 12

                // lucide 没有 arrow-left（原 Sidebar 就画成了空白）—— 用 chevron 旋转 180
                SvgIcon {
                    name: "chevron-right"
                    px: nav.iconPx
                    tint: nav.md3 ? nav.md3.cOnSurfaceVar : "#49454F"
                    rotation: 180
                    anchors.verticalCenter: parent.verticalCenter
                }
                Text {
                    text: "返回经典界面"
                    font.pixelSize: nav.md3 ? nav.md3.bodyM : 14
                    color: nav.md3 ? nav.md3.cOnSurfaceVar : "#49454F"
                    anchors.verticalCenter: parent.verticalCenter
                }
            }
            MouseArea {
                anchors.fill: parent
                cursorShape: Qt.PointingHandCursor
                onClicked: nav.classicRequested()
            }
        }
    }
}
